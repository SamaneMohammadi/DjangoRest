from django.urls import path
from user import views

urlpatterns = [
    path('post-user',views.createuser),
    path('profile',views.profile)
]